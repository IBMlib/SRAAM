NCOM Test data set (Caribean)

Download site:
https://ecowatch.ncddc.noaa.gov/


Spatial extent:

latitude_min: 275
latitude_max: 276
longitude_min: 23
longitude_max: 24


Time coverage:

09-06-2017 00:00:00
11-06-2017 00:00:00
