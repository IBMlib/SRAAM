NEMO Test data set (Mediterranean-sea)

Download site:

http://marine.copernicus.eu/services-portfolio/access-to-products/?option=com_csw&view=details&product_id=MEDSEA_ANALYSIS_FORECAST_PHY_006_013


Spatial extent:

latitude_min: 38
latitude_max: 40
longitude_min: 9
longitude_max: 11


Time coverage:

01-01-2012 00:00:00
10-01-2012 00:00:00
