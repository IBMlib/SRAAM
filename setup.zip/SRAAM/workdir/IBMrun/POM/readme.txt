POM data

Data example is not included in the SRAAM setup. See manual for details on how to recast unsupported hydrographic data formats to the POM format.