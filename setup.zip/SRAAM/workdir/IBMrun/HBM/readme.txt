HBM data (North Sea and Baltic Sea)

Data provider:
Danish Meteorological Institute
www.dmi.dk


Data extent:

Data example is not included in the SRAAM setup. Each daily time frame consists of 4 files of 69 MB each. To access data contact DMI.  